 var AWS = require("aws-sdk");
AWS.config.update({region:'us-west-2'});
var connect = new AWS.Connect();

AWS.config.getCredentials(function(err) {
  if (err) console.log(err.stack);
  // credentials not loaded
  else {
    console.log("Access key:", AWS.config.credentials.accessKeyId);
    console.log("Secret access key:", AWS.config.credentials.secretAccessKey);
  }
});
var params = {
  "InstanceId" : "c180f201-e94e-4434-965c-87effd329a4e",
  "IdentityInfo": {
    "Email": "avinash.agrawal@accenture.com",
    "FirstName": "Avinash",
    "LastName": "Agrawal"
  },
  "Password": "HiAvinash@123",
  "PhoneConfig": {
    "AfterContactWorkTimeLimit": 30,
    "AutoAccept": false,
    "PhoneType": "SOFT_PHONE"
  },
  "RoutingProfileId": "6c70272c-dffd-4e09-9295-20d3914882f8",
  "SecurityProfileIds": [
    "f5b3ee3a-fa52-438f-8edd-72353116a230"
  ],
  "Username": "Avinash"
}

 

connect.createUser(params, function (err, data) {
    if (err) console.log(err, err.stack); // an error occurred
     else     console.log(data);           // successful response
   });