{
  "dependencies": {
    "aws-sdk": "^2.605.0"
  },
  "name": "aws-nodejs-sample",
  "description": "A simple Node.js application illustrating usage of the AWS SDK for Node.js.",
  "version": "1.0.1",
  "main": "sample.js",
  "devDependencies": {},
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "NAME",
  "license": "ISC"
}